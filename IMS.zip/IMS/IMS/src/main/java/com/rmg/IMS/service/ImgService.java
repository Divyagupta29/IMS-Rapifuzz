package com.rmg.IMS.service;

import java.time.Year;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rmg.IMS.database.service.IncidentServiceImpl;
import com.rmg.IMS.database.service.UserDetailServiceImpl;
import com.rmg.IMS.model.UserDetail;
import com.rmg.IMS.model.UserIncident;
import com.rmg.IMS.request.ForgotPasswordRequest;
import com.rmg.IMS.request.LoginRequest;
import com.rmg.IMS.request.UserDetailsResquest;
import com.rmg.IMS.request.UserIncidentRequest;
import com.rmg.IMS.request.updateIncidentRequest;
import com.rmg.IMS.response.CommanResponse;
import com.rmg.IMS.response.GetIncidentResponse;

@Service
public class ImgService {

	@Autowired
	private UserDetailServiceImpl userDetailService;

	@Autowired
	private GetIncidentResponse getIncidentResponse;
	
	@Autowired
	private IncidentServiceImpl incidentService;

	Gson gson = new Gson();
	Gson gsonObj = new GsonBuilder().setPrettyPrinting().create();

	/*
	 * public UserDetailResponse getDeatilService() { stub return null; }
	 */

	public CommanResponse addUser(UserDetailsResquest userDetailsRequest) {
		System.out.print("Inside Add user Controller");

		// Password and Confirm Password Validation
		String password = userDetailsRequest.getpassword();
		String confirmPassword = userDetailsRequest.getconfirmPassword();
		if (!password.equals(confirmPassword)) {
			CommanResponse commanResponse = new CommanResponse();
			commanResponse.setErrorCode(400);
			commanResponse.setStatus("Password and confirm password do not match");
			return commanResponse;
		}

		// Phone Number Validation
		String phoneNo = userDetailsRequest.getPhoneNo();
		if (phoneNo.length() != 10) {
			CommanResponse commanResponse = new CommanResponse();
			commanResponse.setErrorCode(400);
			commanResponse.setStatus("Phone number must be 10 digits long");
			return commanResponse;
		}

		// Email Validation
		String email = userDetailsRequest.getEmailId();
		if (!isValidEmail(email)) {
			CommanResponse commanResponse = new CommanResponse();
			commanResponse.setErrorCode(401);
			commanResponse.setStatus("Invalid email address");
			return commanResponse;
		}

		// Check if email is unique
		if (userDetailService.existsByEmail(email)) {
			CommanResponse commanResponse = new CommanResponse();
			commanResponse.setErrorCode(401);
			commanResponse.setStatus("Email address already exists");
			return commanResponse;
		}

		// Set user details if all validations pass
		UserDetail userDetail = new UserDetail();
		userDetail.setUserName(userDetailsRequest.getUserName());
		userDetail.setEmailId(email);
		userDetail.setAddress(userDetailsRequest.getAddress());
		userDetail.setPin(userDetailsRequest.getPin());
		userDetail.setCity(userDetailsRequest.getCity());
		userDetail.setCountry(userDetailsRequest.getCountry());
		userDetail.setPhoneNo(phoneNo);
		userDetail.setPassword(password);
		userDetail.setconfirmPassword(confirmPassword);

		userDetailService.save(userDetail);

		CommanResponse commanResponse = new CommanResponse();
		commanResponse.setErrorCode(100);
		commanResponse.setStatus("Success");

		return commanResponse;
	}

//-------------------------------------------------------

	public CommanResponse loginUser(LoginRequest loginRequest) {
		UserDetail user = userDetailService.findByEmail(loginRequest.getEmail());
		// Check if user exists
		if (user == null) {
			// If user does not exist, return error response with code 400
			return new CommanResponse("Invalid email", 400);
		} else {
			// If user exists, check if password matches
			if (user.getpassword().equals(loginRequest.getPassword())) {
				// If password matches, return success response with code 200
				return new CommanResponse("Login successful", 200);
			} else {
				// If password is incorrect, return error response with code 400
				return new CommanResponse("Incorrect password", 400);
			}
		}
	}

//--------------------------------------------------
	public CommanResponse addIncident(UserIncidentRequest request) {

		UserDetail user = userDetailService.findByEmail(request.getEmail());
		String email = request.getEmail();
		String password = request.getPassword();

		if (user == null || !user.getpassword().equals(password)) {
			// If email or password is incorrect, return error response
			return new CommanResponse("Invalid credentials", 400);
		} else {

			UserIncident userIncident = new UserIncident();

			userIncident.setRepoterName(request.getRepoterName());
			userIncident.setIncidentDetail(request.getIncidentDetail());
			userIncident.setIncidentId(generateRandomIncidentId());

			if (request.getPriority().equalsIgnoreCase("high") || request.getPriority().equalsIgnoreCase("low")
					|| request.getPriority().equalsIgnoreCase("medium")) {
				userIncident.setPriority(request.getPriority());
			} else {
				userIncident.setPriority("low");
			}

			if (request.getStatus().equalsIgnoreCase("open") || request.getStatus().equalsIgnoreCase("closed")
					|| request.getStatus().equalsIgnoreCase("inprogress")) {
				userIncident.setIncidentStatus(request.getStatus());
			} else {
				userIncident.setIncidentStatus("Inprogress");

			}

			if (!"enterprise".equalsIgnoreCase(request.getIdentity()) && !"government".equalsIgnoreCase(request.getIdentity())) {
			    // If type is not Enterprise or Government, return error response
			    return new CommanResponse("Invalid identity", 422);
			}
			userIncident.setIdentity(request.getIdentity());
			System.out.print("userIncident" + userIncident + "\n");
			incidentService.save(userIncident);
		}

		return new CommanResponse("Login successful", 200);
	}

//-----------------------------------------------
	@Transactional
	public CommanResponse forgotPassword(ForgotPasswordRequest request) {
		try {
			// Find the user by email
			UserDetail user = userDetailService.findByEmail(request.getEmail());
			if (user == null) {
				return new CommanResponse("User with the provided email does not exist", 404);
			}

			// Check if new password and confirm password match
			if (!request.getNewPassword().equals(request.getConfirmPassword())) {
				return new CommanResponse("New password and confirm password do not match", 400);
			}

			// Update the password in the database
			user.setPassword(request.getNewPassword());
			user.setConfirmpassword(request.getConfirmPassword());
			userDetailService.save(user);

			return new CommanResponse("Password updated successfully", 200);
		} catch (Exception e) {
			// Handle any exceptions
			return new CommanResponse("Failed to update password. Please try again later.", 401);
		}
	}

//--------------------------------
	public GetIncidentResponse GetIncidentDetail(String incidentId) {
	    // Check if incident_id is null
	    if (incidentId == null) {
	        return getIncidentResponse.createErrorResponse("Invalid IncidentId", 400);
	    }

	    // Retrieve UserIncident object from service
	    UserIncident userIncident = incidentService.findByIncidentId(incidentId);

	    // Check if userIncident is null or incidentId is null
	    if (userIncident == null || userIncident.getIncidentId() == null ) {
	        return getIncidentResponse.createErrorResponse("Incident not found for given ID", 404);
	    }
	    
	    // Prepare response
	    GetIncidentResponse response = new GetIncidentResponse();
	    response.setIncidentDetail(userIncident.getIncidentDetail());
	    response.setIncidentId(incidentId);
	    response.setIncidentStatus(userIncident.getIncidentStatus());
	    response.setPriorityString(userIncident.getPriority());
	    response.setErrorCode(200);

	    return response;
	}


//-------------------------------
	public GetIncidentResponse updateIncidentDetail(updateIncidentRequest request) {

		UserIncident userIncident = new UserIncident();

		if (request.getIncidentId().isEmpty()|| request.getIncidentId() == null || request == null ) {
            return getIncidentResponse.createErrorResponse("Please enter Incident Id", 400);
        }
		
		userIncident = incidentService.findByIncidentId(request.getIncidentId());
		
		if (userIncident == null || userIncident.getIncidentId() == null ) {
            return getIncidentResponse.createErrorResponse("Invalid incident id or not found", 422);
        }
		
		incidentService.updateIncident(request.getPriority(), request.getIncidentDetail(), request.getIncidentId());

		GetIncidentResponse getIncidentResponse = new com.rmg.IMS.response.GetIncidentResponse();

		getIncidentResponse.setIncidentDetail(request.getIncidentDetail());
		getIncidentResponse.setPriorityString(request.getPriority());
		getIncidentResponse.setRepoterName(userIncident.getRepoterName());
		getIncidentResponse.setIncidentId(userIncident.getIncidentId());

		if (userIncident.getIncidentStatus().equalsIgnoreCase("closed")) {
			getIncidentResponse.setIncidentStatus("closed");
			incidentService.updateStatus("closed", request.getIncidentId());
			getIncidentResponse.setIncidentStatus("closed");

            return getIncidentResponse.createErrorResponse("You can't edit incident status because its already closed", 120);
		}
		getIncidentResponse.setIncidentStatus(request.getStatus());
        getIncidentResponse.setErrorCode(200);


		return getIncidentResponse;

	}



//-------------------------------------
	public boolean isValidEmail(String email) {
		// Check if email is not null or empty
		if (email == null || email.isEmpty()) {
			return false;
		}

		// Split email address into local part and domain part
		String[] parts = email.split("@");

		// Check if email has exactly one "@" symbol
		if (parts.length != 2) {
			return false;
		}

		// Check if local part is not empty
		String localPart = parts[0];
		if (localPart.isEmpty()) {
			return false;
		}

		// Check if domain part is not empty
		String domainPart = parts[1];
		if (domainPart.isEmpty()) {
			return false;
		}

		// Check if domain part contains at least one dot (.)
		if (!domainPart.contains(".")) {
			return false;
		}

		return true;
	}

//----------------------------------------------------------------
	public boolean existsByEmail(String email) {
		// Implement logic to check if a user with the given email exists in the
		// database
		// This is a simplified example assuming you're using Spring Data JPA

		// Assuming you have a UserRepository injected into your service
		return userDetailService.existsByEmail(email);
	}

//-----------------------------
	public static String generateRandomIncidentId() {
		// Generate a random 5-digit number
		Random random = new Random();
		int randomNumber = random.nextInt(90000) + 10000; // Random number between 10000 and 99999

		// Get the current year (assuming 2022)
		int currentYear = Year.now().getValue();

		// Construct and return the Incident ID in the specified format
		return "RMG" + randomNumber + currentYear;
	}

}
